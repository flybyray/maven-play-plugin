package models;

import java.util.List;

public class Category {
	public String name;
	public List<Category> subCategories;
}
