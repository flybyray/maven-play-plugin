package cn.bran.japid.exceptions;

public class JapidRuntimeException extends RuntimeException {

	public JapidRuntimeException(String string) {
		super(string);
	}

}
