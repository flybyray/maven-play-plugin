package controllers;

import play.mvc.*;

public class ClassicController extends Controller {

    public static void index() {
        render();
    }

}
